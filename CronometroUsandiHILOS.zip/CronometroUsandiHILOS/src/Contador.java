
public class Contador extends javax.swing.JFrame {

    public Contador() {
        initComponents();
        btn.setText("Iniciar");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblMinutos = new javax.swing.JLabel();
        btn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblMinutos.setFont(new java.awt.Font("Gill Sans MT", 0, 36)); // NOI18N
        lblMinutos.setForeground(new java.awt.Color(0, 0, 0));
        lblMinutos.setText("0:0");

        btn.setFont(new java.awt.Font("Gill Sans MT", 0, 24)); // NOI18N
        btn.setForeground(new java.awt.Color(0, 0, 0));
        btn.setText("Iniciar");
        btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(83, 83, 83)
                .addComponent(btn)
                .addContainerGap(75, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblMinutos)
                .addGap(96, 96, 96))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(54, Short.MAX_VALUE)
                .addComponent(lblMinutos)
                .addGap(18, 18, 18)
                .addComponent(btn)
                .addGap(36, 36, 36))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
boolean iniciado = false;
    Thread thread = null;
    int segundosTotales = 0;
     int segundos;

    private void btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActionPerformed
 // Declarar la variable iniciado y segundos totales fuera del método
    boolean iniciado = false;
    Thread thread = null;
 
    
    // Obtener el hilo actual
    thread = (Thread) lblMinutos.getClientProperty("thread");
    
    // Si el hilo está detenido y el contador no ha sido iniciado, iniciarlo
    if (thread == null && !iniciado) {
        thread = new Thread() {
            public void run() {
                 segundos = segundosTotales;
                int minutos = 0;
                while (!Thread.currentThread().isInterrupted()) {
                    synchronized (lblMinutos) {
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException ex) {
                            Thread.currentThread().interrupt();
                        }
                        segundos++;
                        if (segundos == 60) {
                            segundos = 0;
                            minutos++;
                        }
                        lblMinutos.setText(String.format("%d:%02d", minutos, segundos));
                    }
                }
                segundosTotales = segundos;
            }
        };
        thread.start();
        lblMinutos.putClientProperty("thread", thread);
        btn.setText("Detener");
        iniciado = true;
    } // Si el hilo está iniciado, detenerlo
    else if (thread != null) {
        thread.interrupt();
        lblMinutos.putClientProperty("thread", null);
        btn.setText("Continuar");
        iniciado = false;
        segundosTotales = getSegundosTotales();
    }
    }
private int getSegundosTotales() {
    String[] tiempo = lblMinutos.getText().split(":");
    int minutos = Integer.parseInt(tiempo[0]);
    int segundos = Integer.parseInt(tiempo[1]);
    return (minutos * 60) + segundos;
}
    private void botonIniciarActionPerformed(java.awt.event.ActionEvent evt) {

    }//GEN-LAST:event_btnActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Contador.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Contador.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Contador.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Contador.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Contador().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn;
    private javax.swing.JLabel lblMinutos;
    // End of variables declaration//GEN-END:variables
}
